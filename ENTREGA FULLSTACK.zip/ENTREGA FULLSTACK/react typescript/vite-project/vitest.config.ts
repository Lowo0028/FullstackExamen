import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'jsdom',
    setupFiles: ['./src/test/tests/setup.ts'],
    globals: true,
    include: ['src/test/tests/**/*.test.ts', 'src/test/tests/**/*.test.tsx'],
  },
});
