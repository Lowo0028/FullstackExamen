// src/pages/inicio.tsx
import React, { useState, useEffect } from "react";
import { animalesService, type Animal } from "../services/animalesService";
import { productosService, type Producto } from "../services/productosService";
import { useNavigate } from "react-router-dom";

export default function Inicio() {
  const [busqueda, setBusqueda] = useState("");
  const [animales, setAnimales] = useState<Animal[]>([]);
  const [productos, setProductos] = useState<Producto[]>([]);
  const navigate = useNavigate();

  // Cargar datos reales al montar el componente
  useEffect(() => {
    // Cargar algunos animales
    animalesService.getAll().then(data => {
        // Tomamos solo los primeros 3 para la portada
        setAnimales(data.slice(0, 3));
    }).catch(console.error);

    // Cargar algunos productos
    productosService.getAll().then(data => {
        setProductos(data.slice(0, 3));
    }).catch(console.error);
  }, []);

  // Navegación
  const irA = (ruta: string) => {
    navigate(ruta);
  };

  return (
    <div className="inicio">
      <h2>🐾 Bienvenido</h2>

      {/* Buscador Visual (Por ahora solo visual, o puedes implementar filtrado frontend sobre lo cargado) */}
      <div className="buscador">
        <input
          type="text"
          placeholder="Buscar animales o productos..."
          className="buscador-input"
          value={busqueda}
          onChange={(e) => setBusqueda(e.target.value)}
        />
      </div>

      <div className="animales-container">
        {/* Renderizar Animales */}
        {animales.map((item) => (
          <div key={`animal-${item.id}`} className="animal-card">
            <img
              src={animalesService.getImageUrl(item.id)}
              alt={item.nombre}
              className="animal-imagen"
              onError={(e) => (e.target as HTMLImageElement).src = "https://via.placeholder.com/150"}
            />
            <h3>{item.nombre}</h3>
            <p>{item.descripcion}</p>
            <button className="btn-adoptar" onClick={() => irA("/adopcion")}>
                Adoptar
            </button>
          </div>
        ))}

        {/* Renderizar Productos */}
        {productos.map((item) => (
          <div key={`prod-${item.id}`} className="animal-card">
            <img
              src={productosService.getImageUrl(item.id)}
              alt={item.nombre}
              className="animal-imagen"
              onError={(e) => (e.target as HTMLImageElement).src = "https://via.placeholder.com/150"}
            />
            <h3>{item.nombre}</h3>
            <p>{item.descripcion}</p>
            <button className="btn-adoptar" onClick={() => irA("/tienda")}>
                Ver producto
            </button>
          </div>
        ))}
        
        {(animales.length === 0 && productos.length === 0) && (
            <p style={{padding: "2rem"}}>Cargando novedades...</p>
        )}
      </div>
    </div>
  );
}