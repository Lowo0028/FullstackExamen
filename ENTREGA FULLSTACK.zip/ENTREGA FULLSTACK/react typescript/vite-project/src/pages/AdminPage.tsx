import React, { useState, useEffect } from "react";
import { animalesService, type Animal } from "../services/animalesService";
import { productosService, type Producto } from "../services/productosService";
import { useAuth } from "../contexts/AuthContext";

export default function AdminPage() {
  const { user } = useAuth(); // Necesitamos el email del admin para las peticiones
  const [isAnimalsView, setIsAnimalsView] = useState(true);
  
  // Listas de datos
  const [animales, setAnimales] = useState<Animal[]>([]);
  const [productos, setProductos] = useState<Producto[]>([]);
  
  // Estado de edición
  const [editItem, setEditItem] = useState<Partial<Animal> | Partial<Producto> | null>(null);
  const [loading, setLoading] = useState(false);

  // Cargar datos al montar
  useEffect(() => {
    cargarDatos();
  }, [isAnimalsView]);

  const cargarDatos = async () => {
    setLoading(true);
    try {
      if (isAnimalsView) {
        const data = await animalesService.getAll();
        setAnimales(data);
      } else {
        const data = await productosService.getAll();
        setProductos(data);
      }
    } catch (error) {
      console.error("Error cargando datos:", error);
      alert("Error al cargar datos del servidor");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editItem || !user?.email) return;

    try {
      if (isAnimalsView) {
        // Lógica Animales
        const item = editItem as Partial<Animal>;
        if (item.id) {
          await animalesService.actualizar(item.id, item, user.email);
          alert("Animal actualizado");
        } else {
          await animalesService.crear(item, user.email);
          alert("Animal creado");
        }
      } else {
        // Lógica Productos
        const item = editItem as Partial<Producto>;
        if (item.id) {
          await productosService.actualizar(item.id, item, user.email);
          alert("Producto actualizado");
        } else {
          await productosService.crear(item, user.email);
          alert("Producto creado");
        }
      }
      setEditItem(null);
      cargarDatos(); // Recargar la lista
    } catch (error) {
      console.error("Error al guardar:", error);
      alert("Error al guardar. Verifica permisos o datos.");
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm("¿Estás seguro de eliminar este item?") || !user?.email) return;

    try {
      if (isAnimalsView) {
        await animalesService.eliminar(id, user.email);
      } else {
        await productosService.eliminar(id, user.email);
      }
      cargarDatos();
    } catch (error) {
      console.error("Error al eliminar:", error);
      alert("No se pudo eliminar.");
    }
  };

  // Renderizado
  return (
    <div className="admin-page">
      <h1>Panel de Administración</h1>

      <div style={{ marginBottom: "1.5rem" }}>
        <button
          className="admin-btn"
          style={{ marginRight: 8, opacity: isAnimalsView ? 1 : 0.6 }}
          onClick={() => { setIsAnimalsView(true); setEditItem(null); }}
        >
          Gestionar Animales
        </button>
        <button
          className="admin-btn"
          style={{ opacity: !isAnimalsView ? 1 : 0.6 }}
          onClick={() => { setIsAnimalsView(false); setEditItem(null); }}
        >
          Gestionar Productos
        </button>
      </div>

      <div className="admin-section">
        <h2>{isAnimalsView ? "Lista de Animales" : "Lista de Productos"}</h2>
        
        {loading ? <p>Cargando...</p> : (
          <ul className="admin-list">
            {isAnimalsView
              ? animales.map((a) => (
                  <li key={a.id}>
                    <div>
                      <strong>{a.nombre}</strong> ({a.especie}) - {a.isAdoptado ? "Adoptado" : "Disponible"}
                    </div>
                    <div>
                      <button className="admin-btn" onClick={() => setEditItem(a)}>Editar</button>
                      <button className="admin-btn" onClick={() => handleDelete(a.id)}>Eliminar</button>
                    </div>
                  </li>
                ))
              : productos.map((p) => (
                  <li key={p.id}>
                    <div>
                      <strong>{p.nombre}</strong> - ${p.precio}
                    </div>
                    <div>
                      <button className="admin-btn" onClick={() => setEditItem(p)}>Editar</button>
                      <button className="admin-btn" onClick={() => handleDelete(p.id)}>Eliminar</button>
                    </div>
                  </li>
                ))
            }
          </ul>
        )}

        <button
          className="admin-btn btn-nuevo"
          onClick={() => setEditItem(isAnimalsView ? {} : {})}
        >
          + Agregar Nuevo
        </button>
      </div>

      {/* FORMULARIO */}
      {editItem && (
        <div className="admin-section" style={{ maxWidth: 500, margin: "2rem auto", border: "1px solid #ccc", padding: "1rem" }}>
          <h3>{editItem.id ? "Editar" : "Crear Nuevo"}</h3>
          <form onSubmit={handleSave} style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
            
            <label>Nombre:</label>
            <input 
              type="text" required 
              value={editItem.nombre || ""} 
              onChange={e => setEditItem({...editItem, nombre: e.target.value})} 
            />

            <label>Descripción:</label>
            <textarea 
              required 
              value={editItem.descripcion || ""} 
              onChange={e => setEditItem({...editItem, descripcion: e.target.value})} 
            />

            {/* CAMPOS ESPECÍFICOS DE ANIMALES */}
            {isAnimalsView ? (
              <>
                <label>Especie:</label>
                <input 
                  type="text" required 
                  value={(editItem as Animal).especie || ""} 
                  onChange={e => setEditItem({...editItem, especie: e.target.value})} 
                />
                <label>Raza:</label>
                <input 
                  type="text" required 
                  value={(editItem as Animal).raza || ""} 
                  onChange={e => setEditItem({...editItem, raza: e.target.value})} 
                />
                <label>Edad:</label>
                <input 
                  type="text" required 
                  value={(editItem as Animal).edad || ""} 
                  onChange={e => setEditItem({...editItem, edad: e.target.value})} 
                />
                <label>Estado:</label>
                <select 
                   value={(editItem as Animal).isAdoptado ? "true" : "false"}
                   onChange={e => setEditItem({...editItem, isAdoptado: e.target.value === "true"})}
                >
                  <option value="false">Disponible</option>
                  <option value="true">Adoptado</option>
                </select>
              </>
            ) : (
              /* CAMPOS ESPECÍFICOS DE PRODUCTOS */
              <>
                <label>Categoría:</label>
                <input 
                  type="text" required 
                  value={(editItem as Producto).categoria || ""} 
                  onChange={e => setEditItem({...editItem, categoria: e.target.value})} 
                />
                <label>Precio:</label>
                <input 
                  type="number" required min="1000"
                  value={(editItem as Producto).precio || 0} 
                  onChange={e => setEditItem({...editItem, precio: Number(e.target.value)})} 
                />
              </>
            )}

            <div style={{ marginTop: "1rem", display: "flex", gap: "1rem" }}>
              <button type="submit">Guardar</button>
              <button type="button" onClick={() => setEditItem(null)}>Cancelar</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}