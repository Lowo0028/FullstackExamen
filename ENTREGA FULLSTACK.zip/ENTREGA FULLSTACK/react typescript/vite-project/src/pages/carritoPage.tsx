import React from "react";
import { type ItemCarrito } from "../services/carritoService";

export interface CarritoProps {
  carrito: ItemCarrito[];
  incrementar: (id: number) => void;
  decrementar: (id: number) => void;
  eliminarDelCarrito: (id: number) => void;
  limpiarCarrito: () => void;
  total: number;

  // ✅ agregar esto
  finalizarCompra: () => Promise<any> | void;
  loading?: boolean;
}

export default function Carrito({
  carrito,
  incrementar,
  decrementar,
  eliminarDelCarrito,
  limpiarCarrito,
  total,
  finalizarCompra,
  loading = false
}: CarritoProps) {
  const handlePagar = async () => {
    try {
      await finalizarCompra();
      alert("Compra realizada con éxito.");
    } catch (e) {
      console.error(e);
      alert("Error al procesar la compra.");
    }
  };

  return (
    <div className="carrito-container">
      <h2>Carrito de compras</h2>

      {carrito.length === 0 ? (
        <p>Tu carrito está vacío.</p>
      ) : (
        <>
          {carrito.map((item) => (
            <div key={item.id} className="carrito-item">
              <img
                src={item.imageUrl || "/placeholder.png"}
                alt={item.productoNombre}
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = "/placeholder.png";
                }}
              />

              <div>
                <h3>{item.productoNombre}</h3>
                <p>${item.productoPrecio}</p>

                <div className="cantidad">
                  <button disabled={loading} onClick={() => decrementar(item.id)}>-</button>
                  <span>{item.cantidad}</span>
                  <button disabled={loading} onClick={() => incrementar(item.id)}>+</button>
                </div>

                <button disabled={loading} onClick={() => eliminarDelCarrito(item.id)}>
                  Eliminar
                </button>
              </div>
            </div>
          ))}

          <h3>Total: ${total}</h3>

          <div style={{ display: "flex", gap: "10px", marginTop: "1rem" }}>
            <button disabled={loading} onClick={limpiarCarrito}>
              Vaciar carrito
            </button>

            <button
              disabled={loading || carrito.length === 0}
              onClick={handlePagar}
            >
              {loading ? "Procesando..." : "Pagar"}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
