import { describe, it, expect, vi, beforeEach } from 'vitest';
import { apiRequest, MICROSERVICES } from '../../../services/api.config';

describe('INTEGRATION - apiRequest (AUTH)', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('POST login: envía JSON y parsea respuesta JSON', async () => {
    const fakeResponse = { success: true, message: 'Login exitoso' };

    const fetchMock = vi.fn(async () => {
      return new Response(JSON.stringify(fakeResponse), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      });
    });

    vi.stubGlobal('fetch', fetchMock as any);

    const res = await apiRequest(`${MICROSERVICES.AUTH}/login`, {
      method: 'POST',
      body: JSON.stringify({ email: 'admin@test.com', contrasena: 'admin123' }),
    });

    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(res).toEqual(fakeResponse);
  });

  it('maneja respuesta no-JSON como texto', async () => {
    const fetchMock = vi.fn(async () => {
      return new Response('OK', {
        status: 200,
        headers: { 'content-type': 'text/plain' },
      });
    });

    vi.stubGlobal('fetch', fetchMock as any);

    const res = await apiRequest(`${MICROSERVICES.AUTH}/ping`, { method: 'GET' });
    expect(res).toBe('OK');
  });
});
