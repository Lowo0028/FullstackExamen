import { describe, it, expect, vi, beforeEach } from 'vitest';
import { apiRequest, MICROSERVICES } from '../../../services/api.config';

describe('INTEGRATION - apiRequest (PRODUCTOS)', () => {
  beforeEach(() => vi.restoreAllMocks());

  it('GET productos retorna lista', async () => {
    const fakeProducts = [{ id: 1, nombre: 'Prod', precio: 1000 }];

    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(JSON.stringify(fakeProducts), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })) as any
    );

    const res = await apiRequest(`${MICROSERVICES.CATALOGO}`, { method: 'GET' });
    expect(Array.isArray(res)).toBe(true);
    expect(res[0].nombre).toBe('Prod');
  });

  it('maneja 500 lanzando error', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(JSON.stringify({ message: 'boom' }), {
        status: 500,
        headers: { 'content-type': 'application/json' },
      })) as any
    );

    await expect(apiRequest(`${MICROSERVICES.CATALOGO}`, { method: 'GET' })).rejects.toBeTruthy();
  });
});
