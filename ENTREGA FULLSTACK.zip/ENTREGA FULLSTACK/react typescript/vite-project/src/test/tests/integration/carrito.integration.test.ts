import { describe, it, expect, vi, beforeEach } from 'vitest';
import { apiRequest, MICROSERVICES } from '../../../services/api.config';

describe('INTEGRATION - apiRequest (CARRITO)', () => {
  beforeEach(() => vi.restoreAllMocks());

  it('GET carrito por usuario retorna array', async () => {
    const fakeItems = [
      { id: 1, usuarioId: 1, productoId: 10, productoNombre: 'X', productoPrecio: 1000, cantidad: 2 },
    ];

    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(JSON.stringify(fakeItems), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      })) as any
    );

    const res = await apiRequest(`${MICROSERVICES.CARRITO}/usuario/1`, { method: 'GET' });
    expect(Array.isArray(res)).toBe(true);
    expect(res).toHaveLength(1);
  });

  it('DELETE vaciar carrito usuario retorna null si content-length 0', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(null, {
        status: 204,
        headers: { 'content-length': '0' },
      })) as any
    );

    const res = await apiRequest(`${MICROSERVICES.CARRITO}/usuario/1`, { method: 'DELETE' });
    expect(res).toBeNull();
  });
});
