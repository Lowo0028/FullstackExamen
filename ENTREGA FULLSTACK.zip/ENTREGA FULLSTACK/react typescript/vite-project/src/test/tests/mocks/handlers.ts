export const mockAuthOk = { success: true, message: 'Login exitoso' };
export const mockAuthFail = { success: false, message: 'Credenciales incorrectas' };

export const mockProductos = [
  { id: 1, nombre: 'Producto Test', precio: 10000, categoria: 'test', imagen: 'test.jpg' },
];

export const mockCarrito = [
  {
    id: 1,
    usuarioId: 1,
    productoId: 1,
    productoNombre: 'Producto Test',
    productoPrecio: 10000,
    cantidad: 2,
    imageUrl: 'test.jpg',
  },
];

export const mockAnimales = [
  {
    id: 1,
    nombre: 'Luna',
    especie: 'Perro',
    raza: 'Labrador',
    edad: '2 años',
    descripcion: 'Perro amigable',
    imagen: 'test.jpg',
    isAdoptado: false,
  },
];
