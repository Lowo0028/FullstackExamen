import { test, expect } from '@playwright/test';

test.describe('E2E - Shopping / Tienda / Carrito', () => {
  test('puede entrar a tienda y ver productos (si existe vista)', async ({ page }) => {
    await page.goto('/');

    // Ajusta el link/botón según tu navbar
    const tiendaLink = page.getByRole('link', { name: /tienda|productos|shop/i }).first();
    if (await tiendaLink.count()) {
      await tiendaLink.click();
    } else {
      await page.goto('/tienda');
    }

    await expect(page.getByText(/producto|tienda|carrito/i).first()).toBeVisible();
  });

  test('puede ir al carrito (si existe ruta)', async ({ page }) => {
    await page.goto('/carrito');
    await expect(page.getByText(/carrito/i).first()).toBeVisible();
  });
});
