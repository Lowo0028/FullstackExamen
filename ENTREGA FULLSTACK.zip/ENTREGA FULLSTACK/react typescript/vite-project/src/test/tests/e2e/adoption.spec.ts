import { test, expect } from '@playwright/test';

test.describe('E2E - Adopción', () => {
  test('debería cargar la vista de adopción (lista o título)', async ({ page }) => {
    await page.goto('/');

    // Si tienes navbar/link
    // Ajusta el texto si tu botón dice distinto
    const link = page.getByRole('link', { name: /adop/i }).first();
    if (await link.count()) {
      await link.click();
    } else {
      // fallback: intenta ruta directa si existe
      await page.goto('/adopcion');
    }

    // Validaciones flexibles (ajusta según tu UI)
    await expect(
      page.getByText(/adop/i).first()
    ).toBeVisible();
  });
});
