import { test, expect } from '@playwright/test';

test.describe('E2E - Login', () => {
  test('login exitoso (mockeable por backend real)', async ({ page }) => {
    await page.goto('/login');

    // En tu Login.tsx vi placeholders: "tu@correo.com" y "••••••••"
    await page.getByPlaceholder('tu@correo.com').fill('admin@test.com');
    await page.getByPlaceholder('••••••••').fill('admin123');

    // Ajusta el texto del botón si difiere
    const submit = page.getByRole('button').filter({ hasText: /iniciar|ingresar|entrar/i }).first();
    await submit.click();

    // Resultado esperado: redirección o algo visible del home
    // Ajusta según tu app
    await expect(page).not.toHaveURL(/\/login$/);
  });

  test('login fallido muestra error', async ({ page }) => {
    await page.goto('/login');

    await page.getByPlaceholder('tu@correo.com').fill('bad@test.com');
    await page.getByPlaceholder('••••••••').fill('badpass');

    const submit = page.getByRole('button').filter({ hasText: /iniciar|ingresar|entrar/i }).first();
    await submit.click();

    await expect(page.getByText(/credenciales|incorrect|error/i).first()).toBeVisible();
  });
});
