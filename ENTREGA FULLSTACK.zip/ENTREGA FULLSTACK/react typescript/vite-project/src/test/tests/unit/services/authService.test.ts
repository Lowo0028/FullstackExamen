import { describe, it, expect, vi, beforeEach } from 'vitest';
import { authService } from '../../../../services/authService';

vi.mock('../../../services/api.config', () => ({
  MICROSERVICES: { AUTH: 'http://localhost:8090/auth' },
  apiRequest: vi.fn(async (_url: string, _opts?: any) => ({ success: true })),
}));

describe('UNIT - authService', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
  });

  it('logout limpia localStorage', () => {
    localStorage.setItem('user', JSON.stringify({ id: 1 }));
    localStorage.setItem('auth_token', 'token');

    authService.logout();

    expect(localStorage.getItem('user')).toBeNull();
    expect(localStorage.getItem('auth_token')).toBeNull();
  });

  it('getCurrentUser retorna null si no hay user', () => {
    expect(authService.getCurrentUser()).toBeNull();
  });
});
