import { describe, it, expect, vi, beforeEach } from 'vitest';
import { carritoService } from '../../../../services/carritoService';
import { apiRequest, MICROSERVICES } from '../../../../services/api.config';

vi.mock('../../../services/api.config', () => ({
  MICROSERVICES: { CARRITO: 'http://localhost:8092/carrito' },
  apiRequest: vi.fn(async () => []),
}));

describe('UNIT - carritoService', () => {
  beforeEach(() => vi.clearAllMocks());

  it('getCarrito llama al endpoint correcto', async () => {
    // Ajusta el nombre real del método si difiere
    await (carritoService as any).getCarrito(1);

    expect(apiRequest).toHaveBeenCalled();
    const [url] = (apiRequest as any).mock.calls[0];
    expect(String(url)).toContain(`${MICROSERVICES.CARRITO}`);
  });
});
