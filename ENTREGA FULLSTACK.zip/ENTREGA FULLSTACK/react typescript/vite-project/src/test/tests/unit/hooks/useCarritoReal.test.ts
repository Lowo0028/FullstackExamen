import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useCarritoReal } from '../../../../hooks/UseCarritoReal';

vi.mock('../../../services/authService', () => ({
  authService: { getCurrentUser: vi.fn(() => ({ id: 1, isAdmin: false })) },
}));

vi.mock('../../../services/carritoService', () => ({
  carritoService: {
    getCarrito: vi.fn(async () => ([
      { id: 1, usuarioId: 1, productoId: 10, productoNombre: 'X', productoPrecio: 1000, cantidad: 2 },
    ])),
  },
}));

vi.mock('../../../services/ordenService', () => ({
  ordenService: {
    // si tu hook lo usa, déjalo mockeado
    crearOrden: vi.fn(async () => ({ ok: true })),
  },
}));

describe('UNIT - useCarritoReal', () => {
  beforeEach(() => vi.clearAllMocks());

  it('carga carrito y calcula total', async () => {
    const { result } = renderHook(() => useCarritoReal());

    // OJO: tu hook debe exponer cargarCarrito (según tu intención)
    // Si tu hook usa useEffect para cargar, puedes omitir esto.
    if (typeof (result.current as any).cargarCarrito === 'function') {
      await act(async () => {
        await (result.current as any).cargarCarrito();
      });
    }

    // Validación flexible (depende de lo que retornes)
    // Ajusta si tu hook retorna { carrito, total, loading, ... }
    const carrito = (result.current as any).carrito ?? [];
    const total = (result.current as any).total ?? 0;

    expect(Array.isArray(carrito)).toBe(true);
    expect(total).toBeGreaterThanOrEqual(0);
  });
});
