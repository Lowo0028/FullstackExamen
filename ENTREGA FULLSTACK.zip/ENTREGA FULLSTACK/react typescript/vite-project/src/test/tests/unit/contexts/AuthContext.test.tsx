import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { AuthProvider, useAuth } from '../../../../contexts/AuthContext';


vi.mock('../../../services/authService', () => {
  return {
    authService: {
      getCurrentUser: vi.fn(() => null),
      login: vi.fn(async () => true),
      register: vi.fn(async () => true),
      logout: vi.fn(() => {}),
      isAdmin: vi.fn(() => false),
      isAuthenticated: vi.fn(() => false),
    },
  };
});

function Consumer() {
  const { isAuthenticated, login, logout, loading } = useAuth();
  return (
    <div>
      <div data-testid="auth">{String(isAuthenticated)}</div>
      <div data-testid="loading">{String(loading)}</div>
      <button onClick={() => login('a@a.com', '123')}>login</button>
      <button onClick={() => logout()}>logout</button>
    </div>
  );
}

describe('UNIT - AuthContext', () => {
  beforeEach(() => vi.clearAllMocks());

  it('renderiza provider y permite usar useAuth()', async () => {
    render(
      <AuthProvider>
        <Consumer />
      </AuthProvider>
    );

    expect(screen.getByTestId('auth').textContent).toBeDefined();
    expect(screen.getByTestId('loading').textContent).toBeDefined();

    fireEvent.click(screen.getByText('login'));
    fireEvent.click(screen.getByText('logout'));
  });
});
