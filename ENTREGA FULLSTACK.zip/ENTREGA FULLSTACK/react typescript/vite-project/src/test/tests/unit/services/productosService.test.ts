import { describe, it, expect, vi, beforeEach } from 'vitest';
import { productosService } from '../../../../services/productosService';
import { apiRequest, MICROSERVICES } from '../../../../services/api.config';

vi.mock('../../../services/api.config', () => ({
  MICROSERVICES: { CATALOGO: 'http://localhost:8091/productos' },
  apiRequest: vi.fn(async () => []),
}));

describe('UNIT - productosService', () => {
  beforeEach(() => vi.clearAllMocks());

  it('getAll llama al endpoint base', async () => {
    // Ajusta el nombre real del método si difiere
    await (productosService as any).getAll?.() ?? (productosService as any).getProductos?.();

    expect(apiRequest).toHaveBeenCalled();
    const [url] = (apiRequest as any).mock.calls[0];
    expect(String(url)).toContain(`${MICROSERVICES.CATALOGO}`);
  });
});
