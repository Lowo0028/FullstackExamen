import { describe, it, expect } from 'vitest';

describe('PERFORMANCE - baseline', () => {
  it('reduce() de 100k elementos debería correr bajo un umbral razonable', () => {
    const arr = Array.from({ length: 100_000 }, (_, i) => i + 1);

    const t0 = performance.now();
    const sum = arr.reduce((acc, n) => acc + n, 0);
    const t1 = performance.now();

    expect(sum).toBe(100_000 * 100_001 / 2);

    // Umbral suave (ajústalo si tu PC es más lento/rápido)
    expect(t1 - t0).toBeLessThan(200);
  });
});
