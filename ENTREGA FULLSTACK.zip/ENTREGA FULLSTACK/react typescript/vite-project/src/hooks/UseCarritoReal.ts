// src/hooks/useCarritoReal.ts
import { useState, useEffect, useCallback } from 'react';
import { carritoService, type ItemCarrito } from '../services/carritoService';
import { ordenService, type ItemOrden } from '../services/ordenService';
import { authService } from '../services/authService';

export function useCarritoReal() {
  const [carrito, setCarrito] = useState<ItemCarrito[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);

  const usuarioActual = authService.getCurrentUser();
  const usuarioId = usuarioActual?.id ? Number(usuarioActual.id) : null;

  const recalcularTotal = (items: ItemCarrito[]) => {
    const nuevoTotal = items.reduce(
      (sum, item) => sum + item.productoPrecio * item.cantidad,
      0
    );
    setTotal(nuevoTotal);
  };

  const cargarCarrito = useCallback(async () => {
    if (!usuarioId) return;

    try {
      setLoading(true);

      const data = await carritoService.getCarrito(usuarioId);
      const items: ItemCarrito[] = Array.isArray(data) ? data : [];

      setCarrito(items);
      recalcularTotal(items);
    } catch (error) {
      console.error('Error al cargar carrito:', error);
      setCarrito([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  }, [usuarioId]);

  useEffect(() => {
    if (usuarioId) {
      cargarCarrito();
    } else {
      setCarrito([]);
      setTotal(0);
    }
  }, [usuarioId, cargarCarrito]);

  const agregarAlCarrito = async (producto: any) => {
    if (!usuarioId) {
      alert('Debes iniciar sesión para agregar productos');
      return;
    }

    try {
      setLoading(true);
      await carritoService.agregarProducto(usuarioId, producto.id, 1);
      await cargarCarrito();
    } catch (error) {
      console.error('Error al agregar al carrito:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const incrementar = async (itemId: number) => {
    const item = carrito.find(i => i.id === itemId);
    if (!item) return;

    try {
      setLoading(true);
      await carritoService.actualizarCantidad(itemId, item.cantidad + 1);
      await cargarCarrito();
    } catch (error) {
      console.error('Error al incrementar:', error);
    } finally {
      setLoading(false);
    }
  };

  const decrementar = async (itemId: number) => {
    const item = carrito.find(i => i.id === itemId);
    if (!item) return;

    try {
      setLoading(true);
      if (item.cantidad <= 1) {
        await carritoService.eliminarItem(itemId);
      } else {
        await carritoService.actualizarCantidad(itemId, item.cantidad - 1);
      }
      await cargarCarrito();
    } catch (error) {
      console.error('Error al decrementar:', error);
    } finally {
      setLoading(false);
    }
  };

  const eliminarDelCarrito = async (itemId: number) => {
    try {
      setLoading(true);
      await carritoService.eliminarItem(itemId);
      await cargarCarrito();
    } catch (error) {
      console.error('Error al eliminar del carrito:', error);
    } finally {
      setLoading(false);
    }
  };

  const limpiarCarrito = async () => {
    if (!usuarioId) return;

    try {
      setLoading(true);
      await carritoService.vaciarCarrito(usuarioId);
      setCarrito([]);
      setTotal(0);
    } catch (error) {
      console.error('Error al limpiar carrito:', error);
    } finally {
      setLoading(false);
    }
  };

  const finalizarCompra = async () => {
    if (!usuarioId || carrito.length === 0) {
      alert('El carrito está vacío');
      return;
    }

    try {
      setLoading(true);

      const itemsOrden: ItemOrden[] = carrito.map(item => ({
        productoId: item.productoId,
        productoNombre: item.productoNombre,
        productoPrecio: item.productoPrecio,
        cantidad: item.cantidad,
        imageUrl: item.imageUrl
      }));

      const orden = await ordenService.crearOrden(usuarioId, total, itemsOrden);

      await carritoService.vaciarCarrito(usuarioId);
      setCarrito([]);
      setTotal(0);

      return orden;
    } catch (error) {
      console.error('Error al finalizar compra:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return {
    carrito,
    total,
    loading,
    agregarAlCarrito,
    incrementar,
    decrementar,
    eliminarDelCarrito,
    limpiarCarrito,
    finalizarCompra,
    cargarCarrito
  };
}
