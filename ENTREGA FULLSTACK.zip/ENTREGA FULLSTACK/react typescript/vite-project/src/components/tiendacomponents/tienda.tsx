import React, { useEffect, useState } from "react";
import { productosService, type Producto } from "../../services/productosService";
import "../../assets/css/style.css";

interface TiendaProps {
  agregarAlCarrito: (producto: Producto) => void;
}

export default function Tienda({ agregarAlCarrito }: TiendaProps) {
  const [productos, setProductos] = useState<Producto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Cargar productos desde el microservicio
  useEffect(() => {
    const cargarProductos = async () => {
      try {
        setLoading(true);
        const data = await productosService.getAll();
        setProductos(data);
      } catch (err: any) {
        console.error("Error al cargar productos:", err);
        setError("Error al cargar los productos. Verifica que el microservicio esté funcionando.");
      } finally {
        setLoading(false);
      }
    };

    cargarProductos();
  }, []);

  const handleAgregar = async (producto: Producto) => {
    try {
      await agregarAlCarrito(producto);
      alert(`${producto.nombre} agregado al carrito 🛒`);
    } catch (error) {
      console.error("Error al agregar al carrito:", error);
      alert("Error al agregar al carrito");
    }
  };

  if (loading) {
    return (
      <section className="tienda">
        <h2>🛍️ Tienda de Productos</h2>
        <div style={{ textAlign: "center", padding: "4rem" }}>
          <p>Cargando productos...</p>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="tienda">
        <h2>🛍️ Tienda de Productos</h2>
        <div style={{ textAlign: "center", padding: "4rem", color: "red" }}>
          <p>{error}</p>
        </div>
      </section>
    );
  }

  return (
    <section className="tienda">
      <h2>🛍️ Tienda de Productos</h2>

      <div className="productos-container">
        {productos.map((p) => (
          <div key={p.id} className="producto-card">
            {/* AQUÍ ESTÁ LA CLAVE: Usar el helper getImageUrl */}
            <img 
              src={productosService.getImageUrl(p.id)} 
              alt={p.nombre} 
              className="producto-imagen"
              onError={(e) => {
                (e.target as HTMLImageElement).src = "https://via.placeholder.com/180?text=Sin+imagen";
              }}
            />
            <h3>{p.nombre}</h3>
            <p><strong>Categoría:</strong> {p.categoria}</p>
            <p>{p.descripcion}</p>
            <p className="precio">${p.precio.toLocaleString("es-CL")}</p>
            <button
              className="btn-adoptar"
              onClick={() => handleAgregar(p)}
            >
              Agregar al carrito
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}