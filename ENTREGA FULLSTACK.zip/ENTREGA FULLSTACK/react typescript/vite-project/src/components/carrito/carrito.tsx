import React from "react";
import "../../assets/css/style.css";
import { type ItemCarrito } from "../../services/carritoService";

interface CarritoProps {
  carrito: ItemCarrito[];
  incrementar: (itemId: number) => void;
  decrementar: (itemId: number) => void;
  eliminarDelCarrito: (itemId: number) => void;
  limpiarCarrito: () => void;              // ✅ nuevo
  total: number;
  finalizarCompra: () => Promise<any> | void;
  loading?: boolean;
}

export default function Carrito({
  carrito,
  incrementar,
  decrementar,
  eliminarDelCarrito,
  limpiarCarrito,
  total,
  finalizarCompra,
  loading = false
}: CarritoProps) {
  const handleFinalizarCompra = async () => {
    try {
      await finalizarCompra();
      alert("Compra realizada con éxito.");
    } catch (error) {
      alert("Error al finalizar la compra. Intenta nuevamente.");
      console.error(error);
    }
  };

  return (
    <div className="carrito-page">
      <div className="carrito-card">
        <h2 className="carrito-title">Carrito de compras</h2>

        {loading && (
          <div className="carrito-loading">
            <p>Cargando carrito...</p>
          </div>
        )}

        {!loading && carrito.length === 0 ? (
          <p className="carrito-empty">Tu carrito está vacío.</p>
        ) : (
          <div className="carrito-list">
            {carrito.map((item) => (
              <div key={item.id} className="carrito-item">
                <img
                  className="carrito-img"
                  src={item.imageUrl || "/placeholder.png"}
                  alt={item.productoNombre}
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = "/placeholder.png";
                  }}
                />

                <div className="carrito-info">
                  <div className="carrito-row">
                    <div>
                      <div className="carrito-name">{item.productoNombre}</div>
                      <div className="carrito-sub">
                        ${item.productoPrecio.toLocaleString("es-CL")} c/u
                      </div>
                    </div>

                    <div className="carrito-sub strong">
                      ${(item.productoPrecio * item.cantidad).toLocaleString("es-CL")}
                    </div>
                  </div>

                  <div className="carrito-actions">
                    <div className="qty">
                      <button
                        className="btn-qty"
                        onClick={() => decrementar(item.id)}
                        disabled={loading}
                      >
                        -
                      </button>

                      <span className="qty-num">{item.cantidad}</span>

                      <button
                        className="btn-qty"
                        onClick={() => incrementar(item.id)}
                        disabled={loading}
                      >
                        +
                      </button>
                    </div>

                    <button
                      className="btn-remove"
                      onClick={() => eliminarDelCarrito(item.id)}
                      disabled={loading}
                    >
                      Eliminar
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="carrito-footer">
          <div className="carrito-total">
            <span>Total</span>
            <strong>${total.toLocaleString("es-CL")}</strong>
          </div>

          <div style={{ display: "flex", gap: "10px" }}>
            <button
              type="button"
              className="btn-secondary"
              onClick={limpiarCarrito}
              disabled={loading || carrito.length === 0}
            >
              Vaciar carrito
            </button>

            <button
              type="button"
              className="btn-checkout"
              onClick={handleFinalizarCompra}
              disabled={loading || carrito.length === 0}
            >
              {loading ? "Procesando..." : "Finalizar compra"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
