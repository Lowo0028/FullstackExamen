import React, { useState, useEffect } from "react";
import { animalesService, type Animal } from "../../services/animalesService"; // Importamos el servicio y el tipo
import { useFavorites } from "../../contexts/FavoritesContext";
import { useAuth } from "../../contexts/AuthContext";
import { formularioService } from "../../services/formularioService";
import "../../assets/css/style.css";

export default function Adopcion() {
  // Eliminamos useAppData
  const { isAuthenticated, user } = useAuth();
  const { toggleFavorite, isFavorite } = useFavorites();
  
  // Estado local para los animales traídos del backend
  const [animals, setAnimals] = useState<Animal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [selectedAnimal, setSelectedAnimal] = useState<number | null>(null);
  const [filtro, setFiltro] = useState<"todos" | "disponibles" | "favoritos">("todos");
  const [formData, setFormData] = useState({
    direccion: "",
    tipoVivienda: "",
    tieneMallasVentanas: false,
    viveEnDepartamento: false,
    tieneOtrosAnimales: false,
    motivoAdopcion: "",
  });

  // 1. Cargar animales desde el Backend al iniciar
  useEffect(() => {
    fetchAnimals();
  }, []);

  const fetchAnimals = async () => {
    try {
      setLoading(true);
      const data = await animalesService.getAll();
      setAnimals(data);
    } catch (err) {
      console.error("Error al cargar animales:", err);
      setError("No se pudieron cargar los animales. Revisa que el backend esté corriendo.");
    } finally {
      setLoading(false);
    }
  };

  // Scroll al top cuando cambia el filtro
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [filtro]);

  // Lógica de filtrado (se mantiene igual, pero opera sobre el estado 'animals')
  const animalesFiltrados = animals.filter((animal) => {
    // Nota: El backend devuelve un booleano isAdoptado, pero el filtro frontend usa strings.
    // Ajustamos la lógica según tu modelo de backend (Animal.java tiene isAdoptado boolean)
    if (filtro === "disponibles") return !animal.isAdoptado; // isAdoptado === false
    if (filtro === "favoritos") return isFavorite(animal.id);
    return true;
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedAnimal === null) return;

    // Flujo eficiente: se usa el usuario autenticado (id) y se crea el formulario real en el microservicio
    if (!isAuthenticated || !user?.id) {
      alert("Debes iniciar sesión para enviar una solicitud de adopción");
      return;
    }

    try {
      await formularioService.crear(user.id, selectedAnimal, {
        direccion: formData.direccion,
        tipoVivienda: formData.tipoVivienda,
        tieneMallasVentanas: formData.tieneMallasVentanas,
        viveEnDepartamento: formData.viveEnDepartamento,
        tieneOtrosAnimales: formData.tieneOtrosAnimales,
        motivoAdopcion: formData.motivoAdopcion,
      });

      const animal = animals.find((a) => a.id === selectedAnimal);
      alert(`Solicitud enviada correctamente.\nAnimal: ${animal?.nombre}`);

      setFormData({
        direccion: "",
        tipoVivienda: "",
        tieneMallasVentanas: false,
        viveEnDepartamento: false,
        tieneOtrosAnimales: false,
        motivoAdopcion: "",
      });
      setSelectedAnimal(null);
    } catch (err: any) {
      console.error("Error al enviar formulario:", err);
      alert(err?.message || "No se pudo enviar el formulario");
    }
  };

  const handleClose = () => setSelectedAnimal(null);

  const handleFavoriteClick = (e: React.MouseEvent, animalId: number) => {
    e.stopPropagation();
    if (!isAuthenticated) {
      alert("Debes iniciar sesión para agregar favoritos");
      return;
    }
    toggleFavorite(animalId);
  };

  // Renderizado de carga o error
  if (loading) return <div style={{textAlign: "center", padding: "2rem"}}>Cargando peluditos... 🐶</div>;
  if (error) return <div style={{textAlign: "center", color: "red", padding: "2rem"}}>{error}</div>;

  return (
    <section className="adopcion">
      <h2>Adopta un Amigo 🐕</h2>

      {/* Filtros */}
      <div style={{ textAlign: "center", marginBottom: "2rem" }}>
        <button
          onClick={() => setFiltro("todos")}
          className={filtro === "todos" ? "active-filter" : ""}
          style={{
            padding: "0.6rem 1.2rem", margin: "0 0.5rem",
            background: filtro === "todos" ? "#7e57c2" : "#e0e0e0",
            color: filtro === "todos" ? "white" : "#333",
            border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: 600,
          }}
        >
          Todos ({animals.length})
        </button>
        <button
          onClick={() => setFiltro("disponibles")}
          style={{
            padding: "0.6rem 1.2rem", margin: "0 0.5rem",
            background: filtro === "disponibles" ? "#7e57c2" : "#e0e0e0",
            color: filtro === "disponibles" ? "white" : "#333",
            border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: 600,
          }}
        >
          Disponibles ({animals.filter((a) => !a.isAdoptado).length})
        </button>
        {isAuthenticated && (
          <button
            onClick={() => setFiltro("favoritos")}
            style={{
              padding: "0.6rem 1.2rem", margin: "0 0.5rem",
              background: filtro === "favoritos" ? "#7e57c2" : "#e0e0e0",
              color: filtro === "favoritos" ? "white" : "#333",
              border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: 600,
            }}
          >
            ❤️ Favoritos ({animals.filter((a) => isFavorite(a.id)).length})
          </button>
        )}
      </div>

      <div className="animales-container">
        {animalesFiltrados.length === 0 ? (
          <p style={{ textAlign: "center", width: "100%", color: "#666" }}>
            No hay animales en esta categoría
          </p>
        ) : (
          animalesFiltrados.map((animal) => (
            <div
              key={animal.id}
              className={`animal-card ${animal.isAdoptado ? "no-disponible" : ""}`}
              onClick={() => !animal.isAdoptado ? setSelectedAnimal(animal.id) : null}
              style={{ position: "relative" }}
            >
              {/* Botón de favorito */}
              {isAuthenticated && (
                <button
                  onClick={(e) => handleFavoriteClick(e, animal.id)}
                  style={{
                    position: "absolute", top: "10px", right: "10px",
                    background: "rgba(255,255,255,0.9)", border: "none",
                    borderRadius: "50%", width: "35px", height: "35px",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    cursor: "pointer", fontSize: "1.2rem", zIndex: 10,
                  }}
                >
                  {isFavorite(animal.id) ? "❤️" : "🤍"}
                </button>
              )}

              {/* IMAGEN DESDE EL BACKEND */}
              <img 
                src={animalesService.getImageUrl(animal.id)} 
                alt={animal.nombre}
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://via.placeholder.com/300x200?text=Sin+Imagen";
                }} 
              />
              
              <h3>{animal.nombre}</h3>
              <p>{animal.especie} • {animal.raza}</p>
              <p className="descripcion">{animal.descripcion}</p>
              <p className={`estado ${!animal.isAdoptado ? "disponible" : "adoptado"}`}>
                {!animal.isAdoptado ? "Disponible" : "Adoptado"}
              </p>
            </div>
          ))
        )}
      </div>

      {selectedAnimal !== null && (
        <div className="modal-adopcion">
          <div className="modal-contenido">
            <button className="btn-cerrar" onClick={handleClose}>✖</button>

            {(() => {
              const animal = animals.find((a) => a.id === selectedAnimal);
              if (!animal) return null;
              return (
                <>
                  <img
                    src={animalesService.getImageUrl(animal.id)}
                    alt={animal.nombre}
                    className="imagen-modal"
                    onError={(e) => (e.target as HTMLImageElement).src = "https://via.placeholder.com/300x200"}
                  />
                  <h2>{animal.nombre}</h2>
                  <p><strong>Especie:</strong> {animal.especie}</p>
                  <p><strong>Raza:</strong> {animal.raza}</p>
                  <p><strong>Edad:</strong> {animal.edad}</p>
                  <p className="descripcion">{animal.descripcion}</p>
                </>
              );
            })()}

            <form className="form-adopcion" onSubmit={handleSubmit}>
              <h3>Formulario de Adopción</h3>

              <label>
                Dirección:
                <input
                  type="text"
                  value={formData.direccion}
                  onChange={(e) => setFormData({ ...formData, direccion: e.target.value })}
                  required
                />
              </label>

              <label>
                Tipo de vivienda:
                <input
                  type="text"
                  value={formData.tipoVivienda}
                  onChange={(e) => setFormData({ ...formData, tipoVivienda: e.target.value })}
                  placeholder="Casa / Departamento"
                  required
                />
              </label>

              <label style={{ display: "block", marginTop: "0.5rem" }}>
                <input
                  type="checkbox"
                  checked={formData.tieneMallasVentanas}
                  onChange={(e) => setFormData({ ...formData, tieneMallasVentanas: e.target.checked })}
                />{" "}
                Tengo mallas en ventanas
              </label>

              <label style={{ display: "block", marginTop: "0.5rem" }}>
                <input
                  type="checkbox"
                  checked={formData.viveEnDepartamento}
                  onChange={(e) => setFormData({ ...formData, viveEnDepartamento: e.target.checked })}
                />{" "}
                Vivo en departamento
              </label>

              <label style={{ display: "block", marginTop: "0.5rem" }}>
                <input
                  type="checkbox"
                  checked={formData.tieneOtrosAnimales}
                  onChange={(e) => setFormData({ ...formData, tieneOtrosAnimales: e.target.checked })}
                />{" "}
                Tengo otros animales
              </label>

              <label>
                Motivo de adopción:
                <textarea
                  value={formData.motivoAdopcion}
                  onChange={(e) => setFormData({ ...formData, motivoAdopcion: e.target.value })}
                  placeholder="Cuéntanos por qué deseas adoptar"
                />
              </label>

              <button type="submit">Enviar Solicitud</button>
            </form>
          </div>
        </div>
      )}
    </section>
  );
}