package com.example.catalogo.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import com.example.catalogo.model.Producto;
import com.example.catalogo.service.ProductoService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/productos")
public class ProductoController {

    private final ProductoService productoService;

    public ProductoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    // ============================
    // OBTENER TODOS
    // ============================
    @GetMapping
    public List<Producto> obtenerTodos() {
        return productoService.obtenerTodos();
    }

    // ============================
    // OBTENER POR ID
    // ============================
    @GetMapping("/{id}")
    public ResponseEntity<Producto> obtenerPorId(@PathVariable Long id) {
        Producto producto = productoService.obtenerPorId(id);
        return producto != null ? ResponseEntity.ok(producto) : ResponseEntity.notFound().build();
    }

    // ============================
    // OBTENER POR CATEGORÍA
    // ============================
    @GetMapping("/categoria/{categoria}")
    public List<Producto> obtenerPorCategoria(@PathVariable String categoria) {
        return productoService.obtenerPorCategoria(categoria);
    }

    // ============================
    // CREAR PRODUCTO (solo admin)
    // ============================
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> crear(@RequestBody Map<String, Object> body) {

        if (body.get("nombre") == null || ((String) body.get("nombre")).isBlank())
            return ResponseEntity.badRequest().body("El nombre no puede estar vacío");

        if (body.get("descripcion") == null || ((String) body.get("descripcion")).isBlank())
            return ResponseEntity.badRequest().body("La descripción no puede estar vacía");

        if (body.get("categoria") == null || ((String) body.get("categoria")).isBlank())
            return ResponseEntity.badRequest().body("La categoría no puede estar vacía");

        if (body.get("precio") == null)
            return ResponseEntity.badRequest().body("El precio es obligatorio");

        Double precio = Double.valueOf(body.get("precio").toString());
        if (precio < 1000)
            return ResponseEntity.badRequest().body("El precio mínimo es 1000 pesos");

        Producto producto = new Producto();
        producto.setNombre((String) body.get("nombre"));
        producto.setDescripcion((String) body.get("descripcion"));
        producto.setCategoria((String) body.get("categoria"));
        producto.setPrecio(precio);

        return ResponseEntity.status(201).body(productoService.crear(producto));
    }

    // ============================
    // ACTUALIZAR PRODUCTO (solo admin)
    // ============================
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> actualizar(
            @PathVariable Long id,
            @RequestBody Map<String, Object> body
    ) {

        if (body.get("nombre") == null || ((String) body.get("nombre")).isBlank())
            return ResponseEntity.badRequest().body("El nombre no puede estar vacío");

        if (body.get("descripcion") == null || ((String) body.get("descripcion")).isBlank())
            return ResponseEntity.badRequest().body("La descripción no puede estar vacía");

        if (body.get("categoria") == null || ((String) body.get("categoria")).isBlank())
            return ResponseEntity.badRequest().body("La categoría no puede estar vacía");

        if (body.get("precio") == null)
            return ResponseEntity.badRequest().body("El precio es obligatorio");

        Double precio = Double.valueOf(body.get("precio").toString());
        if (precio < 1000)
            return ResponseEntity.badRequest().body("El precio mínimo es 1000 pesos");

        Producto producto = new Producto();
        producto.setNombre((String) body.get("nombre"));
        producto.setDescripcion((String) body.get("descripcion"));
        producto.setCategoria((String) body.get("categoria"));
        producto.setPrecio(precio);

        Producto actualizado = productoService.actualizar(id, producto);
        return actualizado != null ? ResponseEntity.ok(actualizado) : ResponseEntity.notFound().build();
    }

    // ============================
    // ACTUALIZAR IMAGEN (solo admin)
    // ============================
    @PostMapping("/{id}/imagen")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> actualizarImagen(
            @PathVariable Long id,
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "emailAdmin", required = false) String emailAdmin
    ) {

        try {
            boolean ok = productoService.actualizarImagen(id, file.getBytes());
            return ok ? ResponseEntity.ok("Imagen actualizada correctamente")
                    : ResponseEntity.notFound().build();
        } catch (IOException e) {
            return ResponseEntity.badRequest().body("Error al leer la imagen");
        }
    }

    // ============================
    // OBTENER IMAGEN
    // ============================
    @GetMapping(
            value = "/{id}/imagen",
            produces = {
                    MediaType.IMAGE_JPEG_VALUE,
                    MediaType.IMAGE_PNG_VALUE,
                    MediaType.IMAGE_GIF_VALUE
            }
    )
    public ResponseEntity<byte[]> obtenerImagen(@PathVariable Long id) {
        Producto producto = productoService.obtenerPorId(id);

        if (producto == null || producto.getImagen() == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok()
                .contentType(MediaType.IMAGE_JPEG)
                .body(producto.getImagen());
    }

    // ============================
    // ELIMINAR PRODUCTO (solo admin)
    // ============================
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> eliminar(
            @PathVariable Long id,
            @RequestParam(value = "emailAdmin", required = false) String emailAdmin
    ) {
        return productoService.eliminar(id)
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }

    // ============================
    // BUSCAR POR NOMBRE
    // ============================
    @GetMapping("/buscar")
    public List<Producto> buscarPorNombre(@RequestParam String nombre) {
        return productoService.buscarPorNombre(nombre);
    }
}
