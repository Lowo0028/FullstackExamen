package com.example.formulario.model;

public enum EstadoFormulario {
    PENDIENTE,
    APROBADO,
    RECHAZADO
}