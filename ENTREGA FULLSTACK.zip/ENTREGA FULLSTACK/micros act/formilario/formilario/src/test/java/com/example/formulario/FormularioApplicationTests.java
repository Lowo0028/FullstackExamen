package com.example.formulario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormularioApplicationTests {

    @Test
    void contextLoads() {
        
    }
}
