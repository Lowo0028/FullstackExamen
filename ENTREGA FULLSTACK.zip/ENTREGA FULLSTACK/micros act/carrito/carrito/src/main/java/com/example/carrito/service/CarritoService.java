package com.example.carrito.service;

import com.example.carrito.Client.ProductoClient;
import com.example.carrito.Client.UsuarioClient;
import com.example.carrito.model.ItemCarrito;
import com.example.carrito.repository.ItemCarritoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class CarritoService {

    private final ItemCarritoRepository itemCarritoRepository;
    private final ProductoClient productoClient;
    private final UsuarioClient usuarioClient;

    public CarritoService(ItemCarritoRepository itemCarritoRepository,
                          ProductoClient productoClient,
                          UsuarioClient usuarioClient) {
        this.itemCarritoRepository = itemCarritoRepository;
        this.productoClient = productoClient;
        this.usuarioClient = usuarioClient;
    }

    // Obtener items del carrito de un usuario
    public List<ItemCarrito> obtenerCarritoPorUsuario(Long usuarioId) {
        Map<String, Object> usuario = usuarioClient.obtenerUsuarioPorId(usuarioId);
        if (usuario == null) {
            throw new IllegalArgumentException("Usuario no encontrado");
        }

        return itemCarritoRepository.findByUsuarioId(usuarioId);
    }

    // Agregar producto al carrito
    @Transactional
    public ItemCarrito agregarAlCarrito(Long usuarioId, Long productoId, Integer cantidad) {
        if (cantidad == null || cantidad <= 0) {
            throw new IllegalArgumentException("Cantidad inválida");
        }

        // Validar que el usuario existe
        Map<String, Object> usuario = usuarioClient.obtenerUsuarioPorId(usuarioId);
        if (usuario == null) {
            throw new IllegalArgumentException("Usuario no encontrado");
        }

        // Validar que el producto existe
        Map<String, Object> producto = productoClient.obtenerProductoPorId(productoId);
        if (producto == null) {
            throw new IllegalArgumentException("Producto no encontrado");
        }

        // Verificar si el producto ya está en el carrito
        Optional<ItemCarrito> itemExistente =
                itemCarritoRepository.findByUsuarioIdAndProductoId(usuarioId, productoId);

        if (itemExistente.isPresent()) {
            ItemCarrito item = itemExistente.get();
            item.setCantidad(item.getCantidad() + cantidad);
            return itemCarritoRepository.save(item);
        }

        // Crear nuevo item
        ItemCarrito nuevoItem = new ItemCarrito();
        nuevoItem.setUsuarioId(usuarioId);
        nuevoItem.setProductoId(productoId);

        // Nombre seguro
        String nombre = (producto.get("nombre") != null)
                ? producto.get("nombre").toString()
                : "Producto";
        nuevoItem.setProductoNombre(nombre);

        // Precio robusto (Integer, Long, Double, BigDecimal, String, etc.)
        Object precioObj = producto.get("precio");
        Double precio = parsePrecio(precioObj);
        nuevoItem.setProductoPrecio(precio);

        nuevoItem.setCantidad(cantidad);

        // Imagen segura
        String imageUrl = (producto.get("imageUrl") != null)
                ? producto.get("imageUrl").toString()
                : "";
        nuevoItem.setImageUrl(imageUrl);

        return itemCarritoRepository.save(nuevoItem);
    }

    private Double parsePrecio(Object precioObj) {
        if (precioObj == null) {
            throw new IllegalArgumentException("Producto sin precio");
        }

        // Si viene como Number (Integer, Long, Double, BigDecimal, etc.)
        if (precioObj instanceof Number) {
            return ((Number) precioObj).doubleValue();
        }

        // Si viene como String (ej: "25990" o "25.990" o "25,990")
        String s = precioObj.toString().trim();
        if (s.isEmpty()) {
            throw new IllegalArgumentException("Producto sin precio");
        }

        // Normalización:
        // - Si usan puntos como separador de miles: "25.990" -> "25990"
        // - Si usan coma decimal: "25990,5" -> "25990.5"
        s = s.replace(".", "").replace(",", ".");

        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Precio inválido: " + precioObj);
        }
    }

    // Actualizar cantidad de un item
    public Optional<ItemCarrito> actualizarCantidad(Long itemId, Integer nuevaCantidad) {
        Optional<ItemCarrito> item = itemCarritoRepository.findById(itemId);

        if (item.isPresent()) {
            ItemCarrito itemActual = item.get();

            if (nuevaCantidad == null || nuevaCantidad <= 0) {
                itemCarritoRepository.delete(itemActual);
                return Optional.empty();
            }

            itemActual.setCantidad(nuevaCantidad);
            return Optional.of(itemCarritoRepository.save(itemActual));
        }

        return Optional.empty();
    }

    // Eliminar item del carrito
    public boolean eliminarItem(Long itemId) {
        if (itemCarritoRepository.existsById(itemId)) {
            itemCarritoRepository.deleteById(itemId);
            return true;
        }
        return false;
    }

    // Vaciar carrito completo de un usuario
    @Transactional
    public void vaciarCarrito(Long usuarioId) {
        Map<String, Object> usuario = usuarioClient.obtenerUsuarioPorId(usuarioId);
        if (usuario == null) {
            throw new IllegalArgumentException("Usuario no encontrado");
        }

        itemCarritoRepository.deleteByUsuarioId(usuarioId);
    }

    // Calcular total del carrito
    public Double calcularTotal(Long usuarioId) {
        Map<String, Object> usuario = usuarioClient.obtenerUsuarioPorId(usuarioId);
        if (usuario == null) {
            throw new IllegalArgumentException("Usuario no encontrado");
        }

        Double total = itemCarritoRepository.calcularTotal(usuarioId);
        return total != null ? total : 0.0;
    }

    // Detalles completos
    public Map<String, Object> obtenerDetallesCarrito(Long usuarioId) {
        Map<String, Object> usuario = usuarioClient.obtenerUsuarioPorId(usuarioId);
        if (usuario == null) {
            throw new IllegalArgumentException("Usuario no encontrado");
        }

        List<ItemCarrito> items = itemCarritoRepository.findByUsuarioId(usuarioId);
        Double total = calcularTotal(usuarioId);

        return Map.of(
                "usuario", usuario,
                "items", items,
                "total", total,
                "cantidadItems", items.size()
        );
    }
}
