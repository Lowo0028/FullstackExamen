package com.example.usuarios.controller;

import com.example.usuarios.repository.UsuarioRepository;
import com.example.usuarios.model.Usuario;
import com.example.usuarios.service.AuthService;
import com.example.usuarios.security.JwtService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/auth")
@Tag(name = "Auth", description = "Autenticación y consultas básicas de usuarios")
public class AuthController {

    private final AuthService authService;
    private final UsuarioRepository usuarioRepository;
    private final JwtService jwtService;

    public AuthController(AuthService authService, UsuarioRepository usuarioRepository, JwtService jwtService) {
        this.authService = authService;
        this.usuarioRepository = usuarioRepository;   // 🔥 INYECCIÓN AGREGADA
        this.jwtService = jwtService;
    }

    // =======================
    //      REGISTRO
    // =======================
    @PostMapping("/register")
    @Operation(summary = "Registrar usuario", description = "Crea un usuario (por defecto ROLE_USER)")
    public ResponseEntity<?> registrar(@RequestBody Usuario usuario) {
        try {
            Usuario registrado = authService.registrar(usuario);
            return ResponseEntity.ok(registrado);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // =======================
    //         LOGIN
    // =======================
    @PostMapping("/login")
    @Operation(summary = "Login", description = "Valida credenciales y retorna JWT Bearer + datos del usuario")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Usuario usuario) {

        var u = usuarioRepository.findByEmail(usuario.getEmail()).orElse(null);
        boolean ok = authService.login(usuario.getEmail(), usuario.getContrasena());
        if (!ok || u == null) {
            return ResponseEntity.status(401).body(Map.of(
                    "message", "Credenciales incorrectas.",
                    "success", false
            ));
        }

        String role = Boolean.TRUE.equals(u.getIsAdmin()) ? "ADMIN" : "USER";
        String token = jwtService.generateToken(u.getEmail(), role);

        Map<String, Object> user = Map.of(
                "id", u.getId(),
                "nombre", u.getNombre(),
                "email", u.getEmail(),
                "telefono", u.getTelefono(),
                "isAdmin", u.getIsAdmin(),
                "rol", role
        );

        return ResponseEntity.ok(Map.of(
                "message", "Login exitoso.",
                "success", true,
                "token", token,
                "user", user
        ));
    }

    // =======================
    //    LISTAR TODOS
    // =======================
    @GetMapping("/usuarios")
    @Operation(summary = "Listar usuarios", description = "Requiere JWT (ROLE_ADMIN recomendado)")
    public ResponseEntity<List<Usuario>> listarTodos() {
        return ResponseEntity.ok(authService.listarUsuarios());
    }

    // =======================
    // BUSCAR POR CORREO 
    // =======================
    @GetMapping("/usuario/correo/{correo}")
    @Operation(summary = "Buscar usuario por correo", description = "Usado por otros microservicios para validar rol")
    public ResponseEntity<?> buscarUsuarioPorCorreo(@PathVariable String correo) {

        Optional<Usuario> usuario = usuarioRepository.findByEmail(correo);

        if (usuario.isEmpty()) {
            return ResponseEntity.status(404).body("Usuario no encontrado");
        }

        Usuario u = usuario.get();
        String rol = Boolean.TRUE.equals(u.getIsAdmin()) ? "ADMIN" : "USER";
        return ResponseEntity.ok(Map.of(
                "id", u.getId(),
                "nombre", u.getNombre(),
                "email", u.getEmail(),
                "rol", rol,
                "telefono", u.getTelefono(),
                "isAdmin", u.getIsAdmin()
        ));
    }

    // =======================
    //    BUSCAR POR ID
    // =======================
    @GetMapping("/usuarios/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        Usuario usuario = authService.buscarPorId(id);
        if (usuario == null) {
            return ResponseEntity.status(404).body("Usuario no encontrado");
        }
        return ResponseEntity.ok(usuario);
    }
}
