package com.example.usuarios.controller;

import com.example.usuarios.model.Usuario;
import com.example.usuarios.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
@Tag(name = "Usuarios", description = "CRUD de usuarios (protegido por JWT y roles)")
public class UsuarioController {

    private final AuthService authService;

    public UsuarioController(AuthService authService) {
        this.authService = authService;
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Listar usuarios", description = "Solo ADMIN")
    public ResponseEntity<List<Usuario>> listar() {
        return ResponseEntity.ok(authService.listarUsuarios());
    }

    @GetMapping("/me")
    @Operation(summary = "Usuario actual", description = "Retorna el usuario asociado al JWT")
    public ResponseEntity<?> me(Authentication auth) {
        if (auth == null) return ResponseEntity.status(401).body("No autenticado");
        String email = auth.getName();
        Usuario u = authService.buscarPorEmail(email);
        return u == null ? ResponseEntity.status(404).body("Usuario no encontrado") : ResponseEntity.ok(u);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Buscar por ID", description = "Solo ADMIN")
    public ResponseEntity<?> obtener(@PathVariable Long id) {
        Usuario u = authService.buscarPorId(id);
        return u == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(u);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Actualizar usuario", description = "Solo ADMIN")
    public ResponseEntity<?> actualizar(@PathVariable Long id, @RequestBody Usuario datos) {
        try {
            Usuario actualizado = authService.actualizar(id, datos);
            return actualizado == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(actualizado);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Eliminar usuario", description = "Solo ADMIN")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        return authService.eliminar(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}
