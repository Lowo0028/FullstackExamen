package com.example.usuarios.service;

import com.example.usuarios.model.Usuario;
import com.example.usuarios.repository.UsuarioRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    
    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    
    public AuthService(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }
    
    // ============================
    //      REGISTRO USUARIO
    // ============================
    public Usuario registrar(Usuario usuario) {

        // Validación: email repetido
        if (usuarioRepository.existsByEmail(usuario.getEmail())) {
            throw new RuntimeException("El correo ya está registrado");
        }

        // Validación: teléfono repetido
        if (usuarioRepository.existsByTelefono(usuario.getTelefono())) {
            throw new RuntimeException("El número de teléfono ya está registrado");
        }

        // Validación: teléfono no vacío
        if (usuario.getTelefono() == null || usuario.getTelefono().isBlank()) {
            throw new RuntimeException("El número de teléfono no puede estar vacío");
        }

        // Validación: limpiar caracteres para contar dígitos
        String telefonoLimpio = usuario.getTelefono().replaceAll("[^0-9]", "");

        // Validación: longitud válida
        if (telefonoLimpio.length() < 8 || telefonoLimpio.length() > 12) {
            throw new RuntimeException("El número de teléfono debe tener entre 8 y 12 dígitos.");
        }

        // Guardar usuario
        usuario.setContrasena(passwordEncoder.encode(usuario.getContrasena()));
        return usuarioRepository.save(usuario);
    }
    
    // =====================================
    //                LOGIN
    // =====================================
    public boolean login(String email, String contrasena) {

        var usuario = usuarioRepository.findByEmail(email).orElse(null);

        if (usuario == null) {
            return false;
        }

        return passwordEncoder.matches(contrasena, usuario.getContrasena());
    }

    // =====================================
    //             LISTAR TODOS
    // =====================================
    public java.util.List<Usuario> listarUsuarios() {
        return usuarioRepository.findAll();
    }

    // =====================================
    //            BUSCAR POR ID
    // =====================================
    public Usuario buscarPorId(Long id) {
        return usuarioRepository.findById(id).orElse(null);
    }

    public Usuario buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email).orElse(null);
    }

    public Usuario actualizar(Long id, Usuario datos) {
        Usuario existente = usuarioRepository.findById(id).orElse(null);
        if (existente == null) return null;

        if (datos.getNombre() != null && !datos.getNombre().isBlank()) {
            existente.setNombre(datos.getNombre());
        }
        if (datos.getTelefono() != null && !datos.getTelefono().isBlank()) {
            // Validación simple similar a registrar
            String telefonoLimpio = datos.getTelefono().replaceAll("[^0-9]", "");
            if (telefonoLimpio.length() < 8 || telefonoLimpio.length() > 12) {
                throw new RuntimeException("El número de teléfono debe tener entre 8 y 12 dígitos.");
            }
            // Evitar duplicado si cambia
            if (!datos.getTelefono().equals(existente.getTelefono())
                    && usuarioRepository.existsByTelefono(datos.getTelefono())) {
                throw new RuntimeException("El número de teléfono ya está registrado");
            }
            existente.setTelefono(datos.getTelefono());
        }
        // Solo si envían contraseña nueva
        if (datos.getContrasena() != null && !datos.getContrasena().isBlank()) {
            existente.setContrasena(passwordEncoder.encode(datos.getContrasena()));
        }
        // Permitir setear admin solo si viene (la protección se hace en el controlador)
        if (datos.getIsAdmin() != null) {
            existente.setIsAdmin(datos.getIsAdmin());
        }

        return usuarioRepository.save(existente);
    }

    public boolean eliminar(Long id) {
        if (!usuarioRepository.existsById(id)) return false;
        usuarioRepository.deleteById(id);
        return true;
    }
    
    // =====================================
    //        CREAR ADMIN INICIAL
    // =====================================
    @PostConstruct
    public void crearAdminInicial() {
        if (usuarioRepository.count() == 0) {
            Usuario admin = new Usuario();
            admin.setNombre("Admin");
            admin.setEmail("admin@amilimetros.cl");
            admin.setTelefono("+56911111111");
            admin.setContrasena(passwordEncoder.encode("Admin123!"));
            admin.setIsAdmin(true);
            usuarioRepository.save(admin);
        }
    }
}
